#!/usr/bin/env python
# coding: utf-8

# In[1]:


get_ipython().system('pip install ibm_watson')


# In[ ]:


url = 'https://api.us-south.text-to-speech.watson.cloud.ibm.com/instances/30d93ab5-e2ae-4263-8596-75ed0092de5d'
api = 'Ks51B_dJSnl2GXaMKA-4sRjGpOhD0wORgZrCkMoq9VEr'


# In[ ]:


from ibm_watson import TextToSppeechVI
from ibm_cloud_sdk_core_authenticators import IAMAuthenticator


# In[ ]:


authenticator = IAMAuthenticator(apikey)
tts = TextToSpeechVI(authenticator=authenticator)
tts.set_service_url(url)


# In[ ]:


with open('./speech.mp3', 'wb') as audio_file: #reads from string
    res = tts.synthesize('Hello Summer', accept='audio/mp3', voice'en-US_AllisonV3Voice').get_result()
    audio_file.write(res.content)


# In[ ]:


#reads from txt file
with open('output.txt', 'r') as f: 
    text = f.readlines()


# In[ ]:


#replace new line in text to space to help in the reading the file
text = [line.replace('\n', '') for line in text] 
text = ''.join(str(line) for line in text)


# In[ ]:


#read the text file vocally 
with open('output.mp3', 'wb') as audio_file: #reads from string
    res = tts.synthesize(text, accept='audio/mp3', voice'en-US_AllisonV3Voice').get_result()
    audio_file.write(res.content)

